package com.example.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.beans.Employee;

@Service
public interface IempService {
List<Employee> getAllEmp();
void addEmp(Employee e);
Employee searchById(int employeeId);
void deleteEmp(int  employeeId);
void update(int  employeeId, String employeeName, double salary, String address);
}
