package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.beans.Employee;
@Component
public class IempRepoImpl implements IempRepository {

	List<Employee> list= new ArrayList<>();
	
	@Override
	public List<Employee> getAllEmp() {
	
		return list;
	}

	@Override
	public void addEmp(Employee e) {
		list.add(e);
		
	}

	@Override
	public void delete(int employeeId) {

		for(Employee e:list)
		{
			if(e.getEmployeeId()==employeeId)
				list.remove(e);
			
		}
	}

	

	@Override
	public Employee search(int employeeId) {
		for(Employee e:list)
		{
			if(e.getEmployeeId()==employeeId)
				return e;
		}
		
		return null;
	}

	@Override
	public void update(Employee e) {
		int Id;
		Id=e.getEmployeeId();
		int itemIndex =0;
		for(Employee a:list)
		{
			
			Employee em=new Employee();
			if(a.getEmployeeId()==Id)
			{
				itemIndex =list.indexOf(e);
				list.set(itemIndex, em);
			}
		}
	}

	
}
