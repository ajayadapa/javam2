package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.beans.Employee;
import com.example.demo.service.IempService;

@Controller
public class EmployeeController {
	  
	@Autowired
	IempService service;
	
	@GetMapping("/getall")
	public ModelAndView getAll() {
		ModelAndView mv=new ModelAndView("showall");
		mv.addObject("employee",service.getAllEmp());
	return mv;
	
	}
	@GetMapping("/adde")
	public ModelAndView addEmployee() {
		ModelAndView mv =new ModelAndView("add");
		mv.addObject("command",new Employee());
		return mv;
	}
	@PostMapping("/addEmployee")
		public String add(Employee e) {
			service.addEmp(e);
			return "redirect:/getall";
			
		}
	@GetMapping("/search")
	public ModelAndView search(@RequestParam("employeeId") int employeeId) {
		ModelAndView  mv=new ModelAndView("showone");
		mv.addObject("employee",service.searchById(employeeId));
		return mv;
	}	
	@GetMapping("/delete")
	public ModelAndView delete(@RequestParam("employeeId") int employeeId) {
		ModelAndView  mv=new ModelAndView("delete");
		mv.addObject("employee");
		service.deleteEmp(employeeId);
		return mv;
	}
	@GetMapping("/update")
	public ModelAndView update(@RequestParam("employeeId") int employeeId) {
		ModelAndView  mv=new ModelAndView("update");
		mv.addObject("employee",service.searchById(employeeId));
		return mv;
	}
	@GetMapping("/update1")
	public ModelAndView update1(@RequestParam("employeeId") int employeeId,@RequestParam("employeeName") String employeeName,@RequestParam("salary") double salary,@RequestParam("address") String address) {
		service.update(employeeId,employeeName,salary,address);
		 return new ModelAndView("redirect:/getall");
	}
	

}
