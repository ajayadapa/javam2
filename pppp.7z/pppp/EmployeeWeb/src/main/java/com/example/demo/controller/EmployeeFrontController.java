package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;


import com.example.demo.beans.Employee;

@Controller
public class EmployeeFrontController {
	
	
	@GetMapping("/getall")
	public ModelAndView getAll() {
		ModelAndView mv=new ModelAndView("showall");
		RestTemplate template = new RestTemplate();
		List<Employee> list = template.getForObject("http://localhost:9395/getall", ArrayList.class);
		mv.addObject("employee",list);
	return mv;
	
	}
	@GetMapping("/adde")
	public ModelAndView addEmployee() {
		ModelAndView mv =new ModelAndView("add");
		mv.addObject("command",new Employee());
		return mv;
	}
	@PostMapping("/addEmployee")
		public String add(Employee e) {
		
		RestTemplate template = new RestTemplate();
		template.postForObject("http://localhost:9395/add",e,String.class);
			return "redirect:/getall";
			
		}
	@GetMapping("/search")
	public ModelAndView search(@RequestParam("employeeId") int employeeId) {
		String response = null;
		Employee emp= new Employee();
		emp.setEmployeeId(employeeId);
		ModelAndView  mv=new ModelAndView("showone");
		RestTemplate template = new RestTemplate();
		
		response=template.postForObject("http://localhost:9395/search", employeeId, String.class);
		mv.addObject("command",new Employee());
		return mv;
	}	
	@GetMapping("/delete")
	public String delete(@RequestParam("employeeId") int employeeId) {
		
		RestTemplate template = new RestTemplate();
		
		String response = null;
		Employee emp= new Employee();
		emp.setEmployeeId(employeeId);
		try {
			response= template.postForObject("http://localhost:9395/deleteEmp", emp, String.class);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("after template: "+ response);
		return "redirect:/getall";
	}
	@GetMapping("/update")
	public ModelAndView update(@RequestParam("employeeId") int employeeId) {
		ModelAndView  mv=new ModelAndView("update");
		mv.addObject( "id" ,new Integer(employeeId));
		mv.addObject("e",new Employee());
		return mv;
	}
	@GetMapping("/update1")
	public String update1(Employee e) {
		System.out.println(">>>>>>>>>>>.");
		RestTemplate template = new RestTemplate();
		template.postForObject("http://localhost:9395/update", e, String.class);
		 return "redirect:/getall";
	}
}
