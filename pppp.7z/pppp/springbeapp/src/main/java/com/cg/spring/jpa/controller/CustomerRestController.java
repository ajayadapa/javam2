package com.cg.spring.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.service.ICustomerService;
import com.cg.spring.jpa.bean.*;
@RestController
public class CustomerRestController {
	
	@Autowired
	ICustomerService service;
	
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public List<Customer> getAll()
	{
		return service.getAll();
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String addCustomer(@RequestBody Customer c)
	{
		service.addCutomer(c);
		return "success";
	}

	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String deleteCustomer(@RequestBody int id)
	{
		service.delete(id);
		return "deleted";
	}

	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@RequestBody Customer c)
	{
		service.update(c);
		return "updated";
	}
	

}
