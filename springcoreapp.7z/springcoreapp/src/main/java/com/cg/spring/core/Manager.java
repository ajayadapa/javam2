package com.cg.spring.core;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
public class Manager implements InitializingBean,DisposableBean{
	private int deptno;
	private String projectname;
	private long projectcode;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public long getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(long projectcode) {
		this.projectcode = projectcode;
	}
	@Override
	public String toString() {
		return "Manager [deptno=" + deptno + ", projectname=" + projectname + ", projectcode=" + projectcode + "]";
	}
	public void init() {
		System.out.println("init method calling from xml");
	}
	public void destroybean() {
		
		System.out.println("destroy method calling from xml");
	}
	@PreDestroy
	public void destroy() throws Exception {
		System.out.println("pre destroy method");
		
	}
	@PostConstruct
	public void afterPropertiesSet() throws Exception {
		System.out.println("postconstruct method");
		
		
	}
}
