package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		
		Employee e1=context.getBean(Employee.class);
		e1.setId(123);
		e1.setName("vijay");
		e1.setSalary(1200);
		System.out.println(e1);
		context.close();
		Manager m1=context.getBean(Manager.class);
		m1.setDeptno(123);
		m1.setProjectname("xyz");
		m1.setProjectcode(100378124);
		System.out.println(m1);
		context.close();
	}

}
