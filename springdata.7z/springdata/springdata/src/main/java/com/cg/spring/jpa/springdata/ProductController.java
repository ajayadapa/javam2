package com.cg.spring.jpa.springdata;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.service.IproductService;
@RestController
@ComponentScan(basePackages="com.cg.spring.jpa")
public class ProductController {
	@Autowired
	IproductService service;
	
	
	public List<Product> getAllProducts(){
	
return service.getAllProducts();
}
}