package com.cg.spring.jpa.springdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.repository.IproductRepo;
@Component
public class ProductServiceImpl implements IproductService {
	
	
@Autowired
IproductRepo repo;


	@Override
	public List<Product> getAllProducts() {
		
		return repo.getAllProducts();
	}

}
