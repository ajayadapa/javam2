package com.cg.spring.jpa.springdata.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;
@Component
public class ProductRepoImpl implements IproductRepo {

List<Product> list;

@Autowired
EntityManager entitymanager;


@Override
public List<Product> getAllProducts(){
	Query q=entitymanager.createQuery("from Product");
	list=q.getResultList();
	return list;
	
}



}
