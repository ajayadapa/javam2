package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.beans.Employee;
import com.example.demo.service.IempService;

@RestController
public class EmployeeBackController {

		@Autowired
		IempService service;
		@RequestMapping(value="/getall",method=RequestMethod.GET)
		public List<Employee> getAll()
		{
			return service.getAllEmp();
		}
		
		@RequestMapping(value="/add",method=RequestMethod.POST)
		public String addCustomer(@RequestBody Employee e)
		{
			service.addEmp(e);
			return "success";
		}

		@RequestMapping(value="/deleteEmp",method=RequestMethod.POST)
		public String deleteCustomer(@RequestBody Employee e)
		{
			service.deleteEmp(e.getEmployeeId());
			return "deleted";
		}

	@RequestMapping(value="/updateEmp",method=RequestMethod.POST)
	public String updateEmp(@RequestParam("employeeId") int employeeId,@RequestParam("employeeName") String employeeName,@RequestParam("salary") double salary,@RequestParam("address") String address)
		{
		
		service.update(employeeId,employeeName,salary,address);		
			return "updated";
		}
	@RequestMapping(value="/searchid",method=RequestMethod.POST)
	public Employee search(@RequestBody Employee e)
		{
		return service.searchById(e.getEmployeeId());		
		}

}
