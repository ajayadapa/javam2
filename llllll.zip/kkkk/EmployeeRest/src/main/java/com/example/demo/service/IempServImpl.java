package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.demo.beans.Employee;
import com.example.demo.repository.IempRepository;

@Component
public class IempServImpl implements IempService {
	@Autowired
	IempRepository repo;

	@Override
	public List<Employee> getAllEmp() {
	
		return repo.getAllEmp();
	}

	@Override
	public void addEmp(Employee e) {
		repo.addEmp(e);
		
	}

	@Override
	public Employee searchById(int  employeeId) {
	
		return  repo.search(employeeId);
	}

	@Override
	public void deleteEmp(int  employeeId) {
		
		repo.delete(employeeId);
	}

	@Override
	public void update(int  employeeId, String employeeName, double salary, String address) {
		repo.update(employeeId,employeeName,salary,address);

	}

	

	
	

}
