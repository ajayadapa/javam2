package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.example.demo.beans.Employee;

@Repository
public interface IempRepository{

  
	List<Employee> getAllEmp();

	void addEmp(Employee e);
	void update(int employeeId, String employeeName, double salary, String address);
	void delete(int employeeId);
	Employee search(int employeeId);

	

}
