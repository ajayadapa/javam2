package com.example.demo.beans;

public class Address { 
	private int homeNo;
	private String streetName;
	private String city;
	private int pincode;
	public int getHomeNo() {
		return homeNo;
	}
	public void setHomeNo(int homeNo) {
		this.homeNo = homeNo;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public Address(int homeNo, String streetName, String city, int pincode) {
		super();
		this.homeNo = homeNo;
		this.streetName = streetName;
		this.city = city;
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [homeNo=" + homeNo + ", streetName=" + streetName + ", city=" + city + ", pincode=" + pincode
				+ "]";
	}
	
	

}
