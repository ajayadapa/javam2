package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.beans.Employee;
@Component
public class IempRepoImpl implements IempRepository {

	List<Employee> list= new ArrayList<Employee>();
	
	@Override
	public List<Employee> getAllEmp() {
	
		return list;
	}

	@Override
	public void addEmp(Employee e) {
		list.add(e);
		
	}

	@Override
	public void delete(int employeeId) {

		for(Employee e:list)
		{
			if(e.getEmployeeId()==employeeId)
				list.remove(e);
			
		}
	}

	@Override
	public void update(int employeeId, String employeeName, double salary, String address) {
		int itemIndex =0;
		for(Employee e:list)
		{
			
			Employee em=new Employee(employeeId, employeeName,salary,address);
			if(e.getEmployeeId()==employeeId)
			{
				itemIndex =list.indexOf(e);
				list.set(itemIndex, em);
			}
		}
	}

	@Override
	public Employee search(int employeeId) {
		for(Employee e:list)
		{
			if(e.getEmployeeId()==employeeId)
				return e;
		}
		
		return null;
	}

	
}
