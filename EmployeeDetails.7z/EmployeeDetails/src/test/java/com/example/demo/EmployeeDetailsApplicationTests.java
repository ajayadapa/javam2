package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.beans.Employee;
import com.example.demo.repository.IempRepoImpl;
import com.example.demo.service.IempServImpl;


@SpringBootTest
public class EmployeeDetailsApplicationTests {
	@InjectMocks
	private IempServImpl   service;
	
	@Mock
	private IempRepoImpl repo;
	
	 @Before
	    public void init() {
	        MockitoAnnotations.initMocks(this);
	    }
	

	@Test
	public void contextLoads() {
	}

	@Test
	public void getAllEmpTest() {
		
		Employee emp = new Employee();
		emp.setEmployeeId(1);
		emp.setEmployeeName("sathwik");
		emp.setSalary(1000);
		emp.setAddress("mancherial");
		List<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		Mockito.when(repo.getAllEmp()).thenReturn(list);
		assertThat(service.getAllEmp()).isEqualTo(list);
	}
	
	@Test
public void addEmployeeTest() {		
		Employee emp = new Employee();
	emp.setEmployeeId(1);
	emp.setEmployeeName("sathwik");
	emp.setSalary(1000);
	emp.setAddress("mancherial");
	service.addEmp(emp);
	 verify(repo, times(1)).addEmp(emp);
		
}
	@Test
	public void employeeSearchTest() {
		Employee emp = new Employee();
		emp.setEmployeeId(1);
		emp.setEmployeeName("sathwik");
		emp.setSalary(1000);
		emp.setAddress("mancherial");
		Mockito.when(repo.search(1)).thenReturn(emp);    
        assertThat(service.searchById(1)).isEqualTo(emp);	
	}
	@Test
	public void deleteEmpTest() {
		Employee emp = new Employee();
		emp.setEmployeeId(1);
		emp.setEmployeeName("sathwik");
		emp.setSalary(1000);
		emp.setAddress("mancherial");
		service.addEmp(emp);
		service.deleteEmp(1);
		 verify(repo, times(1)).delete(1);;
			
		
	}     
 	   
@Test
public void updateEmpTest() {
	Employee emp = new Employee();
	emp.setEmployeeId(1);
	emp.setEmployeeName("sathwik");
	emp.setSalary(1000);
	emp.setAddress("mancherial");
	Mockito.when(repo.search(1)).thenReturn(emp);
	service.update(1, "ajay", 10,"husdih");
	verify(repo, times(1)).update(1, "ajay", 10, "husdih");
	
	
}
}
