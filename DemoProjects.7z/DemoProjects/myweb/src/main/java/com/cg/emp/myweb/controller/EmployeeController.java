/**
 * 
 */
package com.cg.emp.myweb.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.myweb.model.Employee;


/**
 * @author aadapa
 *
 */
@Controller
public class EmployeeController {

	public EmployeeController() {
	}
	
	@GetMapping("/getallEmployees")
	public ModelAndView getAll() {
		ModelAndView mv=new ModelAndView("showall");
		RestTemplate template = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Employee> list = template.getForObject("http://empapi.cfapps.io/capgemini/employee", ArrayList.class);
		mv.addObject("employee",list);
	return mv;
	
	}
	@GetMapping("/openEmployee")
	public ModelAndView addEmployee() {
		ModelAndView mv =new ModelAndView("add");
		mv.addObject("command",new Employee());
		return mv;
	}
	@PostMapping("/addEmployee")
		public String add(Employee e) {
		RestTemplate template = new RestTemplate();
		template.postForObject("http://empapi.cfapps.io/capgemini/employee",e,String.class);
			return "redirect:/getallEmployees";
			
		}
	@GetMapping("/searchEmployee")
	public ModelAndView search(@RequestParam("employeeId") int employeeId) {
	
		ModelAndView  mv=new ModelAndView("showone");
		RestTemplate template = new RestTemplate();
		Employee e=template.getForObject("http://empapi.cfapps.io/capgemini/employee/"+employeeId, Employee.class);
		mv.addObject(e);
		return mv;
	}	
	@GetMapping("/deleteEmployee")
	public String delete(@RequestParam("employeeId") int employeeId) {
		RestTemplate template = new RestTemplate();
	 template.delete("http://empapi.cfapps.io/capgemini/employee/"+employeeId,String.class);
	 System.out.println(".........");
		return "redirect:/getallEmployees";
		
	}
	@GetMapping("/updateOpen")
	public ModelAndView update(@RequestParam("employeeId") int employeeId) {
		ModelAndView  mv=new ModelAndView("update");
		RestTemplate template = new RestTemplate();
		Employee e =  template.getForObject("http://empapi.cfapps.io/capgemini/employee/"+employeeId,Employee.class);
	    mv.addObject(e);
		return mv;
	}
	
	@GetMapping("/updateEmployee1")
	public String update1(Employee e) {
		RestTemplate template = new RestTemplate();
		template.put("http://empapi.cfapps.io/capgemini/employee",e);
			return "redirect:/getallEmployees";
	}

}
