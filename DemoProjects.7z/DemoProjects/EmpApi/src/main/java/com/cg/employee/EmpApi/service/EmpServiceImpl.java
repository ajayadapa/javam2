/**
 * 
 */
package com.cg.employee.EmpApi.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.EmpApi.repository.EmpRepositoryImpl;
import com.cg.employee.EmpApi.vo.Employee;

/**
 * @author aadapa
 *
 */
@Component("service")
public class EmpServiceImpl implements EmpService {

	@Autowired
	EmpRepositoryImpl repo;

	public EmpServiceImpl() {
		super();
	}


	@Override
	public Employee getEmployees(String id) {
		return repo.getEmployees(id);

	}

	
	@Override
	public Set<Employee> getEmployees() {
		return repo.getEmployees();
	}

	
	@Override
	public void addEmployee(Employee e) {
		
		repo.addEmployee(e);
	}

	
	@Override
	public int deleteEmployee(String string) {
		
		repo.deleteEmployee(string);
		return 0;
	}

	
	@Override
	public int updateEmployee(Employee e) {
		repo.updateEmployee(e);
		return 0;
	}

}
