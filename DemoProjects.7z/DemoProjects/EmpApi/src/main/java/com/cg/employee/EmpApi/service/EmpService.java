/**
 * 
 */
package com.cg.employee.EmpApi.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.cg.employee.EmpApi.vo.Employee;

/**
 * @author aadapa
 *
 */
@Service
public interface EmpService {

	Employee getEmployees(String id);

	Set<Employee> getEmployees();

	void addEmployee(Employee e);

	int deleteEmployee(String string);

	int updateEmployee(Employee e);

}
