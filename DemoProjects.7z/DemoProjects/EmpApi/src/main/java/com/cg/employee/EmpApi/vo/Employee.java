/**
 * 
 */
package com.cg.employee.EmpApi.vo;

/**
 * @author aadapa
 *
 */
public class Employee {

	private int employeeId;
	private String employeeName;
	private double salary;
	private String address;

	/*public Employee(int employeeId, String employeeName, double salary, String address) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.address = address;
	}*/

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public Employee() {
		//super();
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public String getAddress() {
		return address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;

		result = prime * result + employeeId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;

		if (employeeId != other.employeeId)
			return false;

		return true;
	}
}
