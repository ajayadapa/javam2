package com.cg.employee.EmpApi.repository;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.cg.employee.EmpApi.vo.Employee;

@Component("repo")
public class EmpRepositoryImpl implements EmpRepository {
	Set<Employee> list;
	public EmpRepositoryImpl() {
		if (list == null || list.isEmpty()) {
			list = new HashSet<Employee>();
		}
	}

	@Override
	public Employee getEmployees(String id) {
		return getEmployeeFromList(id);
	}

	/**
	 * @param id
	 */
	private Employee getEmployeeFromList(String id) {
		for (Employee e : list) {
			if (e.getEmployeeId() == Integer.parseInt(id))
				return e;
		}
		return null;
	}

	@Override
	public Set<Employee> getEmployees() {

		return list;
	}

	@Override
	public void addEmployee(Employee e) {
		list.add(e);

	}

	@Override
	public int deleteEmployee(String id) {
		Employee e = getEmployeeFromList(id);
		if (e != null) {
			list.remove(e);
			return 1;
		}
		return 0;
	}

	@Override
	public int updateEmployee(Employee e) {
		int count = 0;
		for (Employee emp : list) {
			// Employee em=new Employee(employeeId, employeeName,salary,address);
			if (emp.getEmployeeId() == e.getEmployeeId()) {
				emp.setAddress(e.getAddress());
				emp.setEmployeeName(e.getEmployeeName());
				emp.setSalary(e.getSalary());
				count++;
				break;
			}
		}
		return count;

	}

}
