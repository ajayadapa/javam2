/**
 * 
 */
package com.cg.employee.EmpApi;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author aadapa
 *
 */
@Configuration
public class EmpApiConfig {

	/**
	 * 
	 */
	public EmpApiConfig() {
		
	}
	
	/*@Bean 
	public DataSource getDataSource() {
		return null;
	}
	*/

}
