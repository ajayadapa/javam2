package com.cg.employee.EmpApi.repository;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.cg.employee.EmpApi.vo.Employee;

@Repository
public interface EmpRepository {

	Employee getEmployees(String id);

	Set<Employee> getEmployees();

	void addEmployee(Employee e);

	int deleteEmployee(String string);

	int updateEmployee(Employee e);
	
	

}
