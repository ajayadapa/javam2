package com.cg.employee.EmpApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpApiApplication.class, args);
	}

}
