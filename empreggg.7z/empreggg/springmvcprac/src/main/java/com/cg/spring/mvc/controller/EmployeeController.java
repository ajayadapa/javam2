package com.cg.spring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;

import com.cg.spring.mvc.service.IEmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	IEmployeeService service;
	
	
	@RequestMapping(value="/getall", method=RequestMethod.GET)
	
	public ModelAndView getAll() {
		ModelAndView  mv=new ModelAndView("showall");
		mv.addObject("employee",service.getAllEmp());
		return mv;
	}
	
	@RequestMapping(value="/adde" ,method=RequestMethod.GET)
	public ModelAndView addEmpy()
	{
		ModelAndView  mv=new ModelAndView("add");
		mv.addObject("command",new Employee());
		return mv;
		
	}
	@RequestMapping(value="/addEmployee", method=RequestMethod.POST)
	public String add(Employee e) {
		service.addEmp(e);
		return "redirect:/getall";
	}
	
	@RequestMapping(value="/search", method=RequestMethod.GET)
	public ModelAndView Search(@RequestParam("id") int id) {
		ModelAndView  mv=new ModelAndView("showone");
		mv.addObject("employee",service.searchById(id));
		return mv;
	}
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String Delete(@RequestParam("id") int id) {
		service.deleteEmp(id);
		return "redirect:/getall";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.GET)
	public ModelAndView update(@RequestParam("id") int id) {
		ModelAndView  mv=new ModelAndView("update");
		mv.addObject("employee",service.searchById(id));
		return mv;
	}
	@RequestMapping(value="/update1", method=RequestMethod.GET)
	public ModelAndView update1(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("salary") double salary,@RequestParam("age") int age,@RequestParam("address") String address) {
		service.update(id,name,salary,age,address);
		 return new ModelAndView("redirect:/getall");
	}
	/*@RequestMapping(value="/update1", method=RequestMethod.GET)
	public String update1(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("salary") double salary) {
		service.update(id,name,salary);
		return "redirect:/getall";
	}*/
	/* @RequestMapping(value="/save",method = RequestMethod.POST)  
	    public ModelAndView save(@ModelAttribute("emp") Emp emp){  
	        dao.save(emp);  
	        return new ModelAndView("redirect:/viewemp");//will redirect to viewemp request mapping  
	    }  */
}
