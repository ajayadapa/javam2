package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Employee;

@Service
public interface IEmployeeService {
	
	List<Employee> getAllEmp();
	void addEmp(Employee e);
	Employee searchById(int id);
	void deleteEmp(int id);
	void update(int id,String name,double salary,int age ,String address);

}
