package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;

@Component
public class EmployeeRepImpl implements IEmployeeRep {

	
	List<Employee> list =new ArrayList<Employee>();
	public List<Employee> getAllEmp() {
		
		return list;
	}
	
	public void addEmp(Employee e) {
		
//		e.setId(list.size()+1);
		list.add(e);
	}

	public Employee searchById(int id) {
		
		for(Employee e:list)
		{
			if(e.getId()==id)
				return e;
		}
		return null;
	}

	public void deleteEmp(int id) {
	

		for(Employee e:list)
		{
			if(e.getId()==id)
				list.remove(e);
			
		}
		
	}

	public void update(int id, String name, double salary,int age,String address) {
	
		int itemIndex =0;
		for(Employee e:list)
		{
			
			Employee em=new Employee(id, name,salary,age,address);
			if(e.getId()==id)
			{
				itemIndex =list.indexOf(e);
				list.set(itemIndex, em);
			}
			/*if(e.getId()==id)
			{
				e.setName(name);
				e.setSalary(salary);
				 
			}*/
		}
	    
	  }

	
}

	



