package com.cg.spring.mvc.beans;

public class Employee {
	
	private int id;
	private String name;
	private double salary;
	public Employee(int id, String name, double salary, int age, String address) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.address = address;
	}
	private int age;
	private String address;
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Employee() {}
//	public Employee(int id, String name, double salary) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
//	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", age=" + age + ", address=" + address
				+ "]";
	}
	

}
