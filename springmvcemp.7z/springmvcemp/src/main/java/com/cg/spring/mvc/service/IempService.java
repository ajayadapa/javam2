package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Employee;
@Service
public interface IempService {

	List<Employee> getAllEmployees();

	void add(Employee p);

	Employee searchById(int id);

}
