package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.repository.IemployeeRepo;

public class EmpServiceImpl implements IempService {
	
	@Autowired
	IemployeeRepo repo;

	public List<Employee> getAllEmployees() {
		
		return repo.getAllEmployees();
	}

	public void add(Employee p) {

repo.add(p);
		
	}

	public Employee searchById(int id) {
		
		return repo.SearchById(id);
	}
	
	

}
