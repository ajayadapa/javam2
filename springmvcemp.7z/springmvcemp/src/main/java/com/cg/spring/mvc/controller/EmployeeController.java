package com.cg.spring.mvc.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.service.IempService;


@Controller
public class EmployeeController {
	@Autowired
	IempService service;
	
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getAllEmployees() {
		ModelAndView mv=new ModelAndView("showall");
		mv.addObject("employees",service.getAllEmployees());
		return mv;
	}
	
	@RequestMapping(value="/addp",method=RequestMethod.GET)
	public ModelAndView addEmployee() {
		ModelAndView mv=new ModelAndView("add");
		mv.addObject("command",new Employee());
		return mv;
	}
	
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String add(Employee p) {
		service.add(p);
		
		return "redirect:/getall";
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ModelAndView SearchProduct(@RequestParam("id")int id) {
		ModelAndView mv=new ModelAndView("search");
		mv.addObject("product",service.searchById(id));
		return mv;
	

}
	
}
	
