package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;


@Component
public class EmployeeRepoImpl implements IemployeeRepo{
	
	
	List<Employee> list=new ArrayList();

	public void add(Employee p) {
		Employee p1=new Employee();
		p1.setId(list.size()+1);
		p1.setName("ajay");
		p1.setSal(6456);
		p1.setMail("aj@gmail.com");
		list.add(p1);
		Employee p2=new Employee();
		p2.setId(2);
		p2.setName("samsung galaxy");
		p2.setMail("aja@gmail.com");
		p2.setSal(15.02);
		list.add(p2);
		p.setId(list.size() +1);
		list.add(p);
		
		
		
		
	}

	public List<Employee> getAllEmployees() {
		
		
		return list;
	}

	public Employee SearchById(int id) {
		for(Employee p:list) {
			if(p.getId()==id)
				return p;
		}
		return null;
		
	}

}
