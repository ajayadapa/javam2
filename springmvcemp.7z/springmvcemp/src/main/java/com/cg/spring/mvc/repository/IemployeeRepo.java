package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.beans.Employee;
@Repository
public interface IemployeeRepo {

	void add(Employee p);

	List<Employee> getAllEmployees();

	Employee SearchById(int id);

}
