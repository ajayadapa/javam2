package com.cg.spring.javaconfig;

import java.security.PublicKey;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan(basePackages="com.cg.spring.javaconfig")
public class ProductConfiguration {
	@Bean
	public Product getProduct() {

		Product p=new Product();
		p.setProductname("ios");
		p.setProductprice(85200);
		return p;
	}

	
	

}
