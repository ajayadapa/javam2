package com.cg.spring.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.Customer;
import com.cg.spring.jpa.service.ICustomerService;

@RestController
@ComponentScan(basePackages="com.cg.spring.jpa")
public class CustomerRestController {
	@Autowired
	ICustomerService service;
	
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public List<Customer> getAllProducts()
	{
	return service.getAll();	
	}
	

}
